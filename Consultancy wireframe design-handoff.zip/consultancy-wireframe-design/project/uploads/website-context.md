# Website Build — Context for Claude Code

This document is the brief for building my consultancy website. Read it fully before writing code or copy.

## Read these first

Before you write a word of copy, read every file in `About Me/`:

- `about-me` — who I am, what I love and hate
- `anti-ai-writing-style` — how NOT to write. Audit all copy against this.
- `my-company` — my role and positioning context

Also read my resume (point me to it if you can't find it). Pull my voice, real proof, and career detail from these sources. Do not invent achievements, metrics, logos, or testimonials. If a claim isn't backed by these files, leave a clearly marked `[PLACEHOLDER: ...]` and flag it.

## Who I am

Divya. Product marketing consultant, going full-time by October 2026. I run a Growth-PMM practice: a small book of 4–6 SMB retainer anchors, not a 20-client agency. Target revenue is $100K–$250K in year one.

## What this website is for

One job: **convert the right visitor into a discovery call.** This is a lead-gen site, not a brochure and not a blog. Every page should move toward a single CTA: book a call. Keep secondary CTAs out of the way.

The most important near-term outcome it supports: landing my first paid audit engagements with Indian Series-A to C B2B SaaS companies that are post product-market fit. Lead with that wedge offer.

## Who it's for (ICP)

- Post-PMF SMB B2B SaaS companies
- Stage: roughly Series A to C
- Markets: India first, US second
- Buyer: founder, CEO, or first marketing/growth hire who knows their GTM is leaking but can't name where

Write copy to that person. Name their problem in their words before pitching the solution.

## What I sell

- Go-to-market strategy
- Positioning & messaging
- Product launches
- Pricing strategy
- Content & thought leadership

The front-door offer is a **paid GTM / positioning audit** — a low-commitment way to start that converts into retainer work. Make this the hero offer; present the rest as the deeper engagement that follows.

## Voice and writing rules

Match my voice from `about-me` and audit against `anti-ai-writing-style`. Non-negotiables:

- No em-dashes
- No bullet lists where prose works
- No bold mid-sentence for emphasis
- Banned verbs: leverage, utilize, and the rest in the anti-AI file
- Take a stance. No hedging, no "in today's fast-paced world"
- Open with the answer, then support it

Copy should sound like a sharp operator who has done the work, not a marketing brochure.

## Site structure (recommendation, not a mandate)

Keep it tight. A single strong page beats five thin ones. Suggested:

1. **Hero** — the wedge offer in one line, who it's for, the book-a-call CTA
2. **The problem** — name the post-PMF GTM leak in the buyer's language
3. **What I do** — the audit offer, then the broader services
4. **Proof** — real results / experience pulled from resume and About Me (placeholders if thin)
5. **About** — credibility, why me, why now
6. **CTA** — book a discovery call (embed scheduling if I have a link; otherwise placeholder)

## Build decisions (your call)

You choose the stack — pick whatever ships a fast, clean, easily-editable site I can maintain and grow a blog onto later. State your choice and why before building. Constraints:

- Fast load, mobile-first, accessible
- Easy for a non-developer to edit copy
- Cheap/simple hosting (Vercel, Netlify, or similar) — give me deploy steps
- SEO basics: title, meta description, Open Graph, semantic HTML
- One analytics hook and the booking CTA wired in

## What I need from you

1. Confirm what you read and flag anything missing (resume, scheduling link, proof points)
2. Recommend the stack and structure, then build it
3. Write all copy in my voice, audited against the anti-AI rules
4. Mark every unverified claim as a placeholder
5. Give me clear instructions to edit copy and deploy

Ask me the single most important question before you start. Don't fill gaps with filler.
